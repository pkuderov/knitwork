import importlib


# Model registry
MODELS_ROOT = 'knitwork.models'

REGISTRY = {
    "rnn": "gru.GruCore",
    "grnn": "grnn_core.GridRnn",
    "grnn_lru": "grnn_lru_core.GridRnn",
    "delta_net": "baseline.delta_net.DeltaNetCore",
    "hgrn2": "baseline.hgrn2.HGRN2Core",
    "mlstm": "baseline.mlstm.mLSTMCore",
    "transformer": "baseline.transformer.TransformerCore",
    "rims": "baseline.rims.RimsCore",
    "brims": "baseline.rims.BrimsCore"
}

WRAPPER_REGISTRY = {
    'token': 'wrappers.TokenModel',
    'rl_token': 'wrappers.RLTokenModel',
    'rl_vector': 'wrappers.RLVectorModel',
}


def build_model(wrapper_type: str, wrapper_cfg: dict, rnn_type: str, rnn_cfg: dict):
    model_fn = resolve_model(wrapper_type, WRAPPER_REGISTRY)
    rnn_fn = resolve_model(rnn_type, REGISTRY)

    return model_fn(
        **wrapper_cfg,
        rnn=rnn_cfg, rnn_fn=rnn_fn,
    )


def resolve_model(rnn_type: str, registry: dict):
    cls_path = registry[rnn_type]
    import_path, cls_name = cls_path.rsplit('.', 1)
    import_path = f'{MODELS_ROOT}.{import_path}'
    return getattr(importlib.import_module(import_path), cls_name)
